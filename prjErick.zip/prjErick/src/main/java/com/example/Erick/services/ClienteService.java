package com.example.Erick.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Erick.entities.Cliente;
import com.example.Erick.repositories.ClienteRepository;


public class ClienteService {
	@Autowired
	private ClienteRepository clienteRepository;

	public List<Cliente> getAllCliente() {
		return clienteRepository.findAll();
	}

	public Cliente getClienteById(BigInteger id) {
		return clienteRepository.findById(id).orElse(null);
	}

	public Cliente saveCliente(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

}
