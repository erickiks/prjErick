package com.example.Erick.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Erick.entities.Produto;
import com.example.Erick.repositories.ProdutoRepository;


public class ProdutoService {
	
	@Autowired
	private ProdutoRepository produtoRepository;

	public List<Produto> getAllProduto() {
		return produtoRepository.findAll();
	}

	public Produto getProdutoById(BigInteger id) {
		return produtoRepository.findById(id).orElse(null);
	}

	public Produto saveProduto(Produto produto) {
		return produtoRepository.save(produto);
	}

}
