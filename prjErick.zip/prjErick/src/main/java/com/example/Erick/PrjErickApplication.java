package com.example.Erick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjErickApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjErickApplication.class, args);
	}

}
