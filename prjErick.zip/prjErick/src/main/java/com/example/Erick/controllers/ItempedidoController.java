package com.example.Erick.controllers;

import java.math.BigInteger;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Erick.entities.Itempedido;

import com.example.Erick.services.ItempedidoService;

@RestController
@RequestMapping("/itempedido")
public class ItempedidoController {
	
private final ItempedidoService itempedidoService;
	
	public ItempedidoController(ItempedidoService itempedidoService) {
		this.itempedidoService = itempedidoService;
}

	@GetMapping("/{id}")
	public ResponseEntity<Itempedido> findItempedidobyId(@PathVariable BigInteger id) {
		Itempedido itempedido = itempedidoService.getItempedidoById(id);
		if (itempedido != null) {
			return ResponseEntity.ok(itempedido);
		} else {
			return ResponseEntity.notFound().build();
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<List<Itempedido>> findAllUsuarioscontrol() {
		List<Itempedido> itempedido = itempedidoService.getAllItempedido();
		return ResponseEntity.ok(itempedido);
	}
	
	@PostMapping("/{id}")
	public ResponseEntity<Itempedido> insertUsuariosControl(@RequestBody Itempedido itempedido) {
		Itempedido novoitempedido = itempedidoService.saveItempedido(itempedido);
		return ResponseEntity.status(HttpStatus.CREATED).body(novoitempedido);
	}


}
