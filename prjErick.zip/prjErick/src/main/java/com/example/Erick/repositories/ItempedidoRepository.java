package com.example.Erick.repositories;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Erick.entities.Itempedido;


public interface ItempedidoRepository extends JpaRepository<Itempedido, BigInteger> {

}
