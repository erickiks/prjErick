package com.example.Erick.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Erick.entities.Fornecedor;
import com.example.Erick.repositories.FornecedorRepository;


public class FornecedorService {
	
	@Autowired
	private FornecedorRepository fornecedorRepository;

	public List<Fornecedor> getAllFornecedor() {
		return fornecedorRepository.findAll();
	}

	public Fornecedor getFornecedorById(BigInteger id) {
		return fornecedorRepository.findById(id).orElse(null);
	}

	public Fornecedor saveFornecedor(Fornecedor fornecedor) {
		return fornecedorRepository.save(fornecedor);
	}


}
