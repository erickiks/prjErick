package com.example.Erick.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Erick.entities.Pedido;
import com.example.Erick.repositories.PedidoRepository;


public class PedidoService {

	@Autowired
	private PedidoRepository pedidoRepository;

	public List<Pedido> getAllPedido() {
		return pedidoRepository.findAll();
	}

	public Pedido getPedidoById(BigInteger id) {
		return pedidoRepository.findById(id).orElse(null);
	}

	public Pedido savePedido(Pedido pedido) {
		return pedidoRepository.save(pedido);
	}
	
}
