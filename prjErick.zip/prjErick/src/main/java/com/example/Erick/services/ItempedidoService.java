package com.example.Erick.services;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.Erick.entities.Itempedido;
import com.example.Erick.repositories.ItempedidoRepository;
;

public class ItempedidoService {
	
	@Autowired
	private ItempedidoRepository itempedidoRepository;

	public List<Itempedido> getAllItempedido() {
		return itempedidoRepository.findAll();
	}

	public Itempedido getItempedidoById(BigInteger id) {
		return itempedidoRepository.findById(id).orElse(null);
	}

	public Itempedido saveItempedido(Itempedido itempedido) {
		return itempedidoRepository.save(itempedido);
	}

}
