package com.example.Erick.repositories;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Erick.entities.Pedido;


public interface PedidoRepository extends JpaRepository<Pedido, BigInteger> {

}
